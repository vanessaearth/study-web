# Terisa Live2D
Terisa Live2D是一个基于live2d.js提取改造的Live2D模型，人物形象是上海米哈游旗下崩坏系列的德利莎，版权为miHoYo所有。欢迎各位Star

## 展示
![](https://yun.clf.red/?/images/2019/01/04/evHj0mcEEY/terisa.png)

## 如何使用？

#### 下载模型文件：

[Github](https://github.com/lychs1998/Terisa_live2D/archive/master.zip "Github") [蓝凑云](https://www.lanzous.com/i2ry0le "蓝凑云")

#### 配合插件使用

Typecho博客可以使用：[Pio插件](https://github.com/Dreamer-Paul/Pio "Pio插件")

WordPress博客可以使用：[33-live2d-wp](https://github.com/xb2016/33-live2d-wp "33-live2d-wp")by 喵喵

Emlog博客可以使用：[live2D插件](https://www.wikimoe.com/?post=75 "live2D") by 广树

Z-blog博客可以使用：[Live2D插件](https://www.fghrsh.net/post/123.html "Live2D插件")
by FGHRSH

将压缩包上传到插件的模型目录下即可，各个插件也有相应的教程～

## 更多模型？

前往下载：[梦象](https://mx-model.ga/ "梦象")
